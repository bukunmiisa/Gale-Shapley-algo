const fs = require('fs');
const { faker } = require('@faker-js/faker');

// Parameters for random generation
const numStudents = 50;
const departments = ["science", "literature", "engineering", "arts"];
const subjects = [
    "environmental science", "modern literature", "quantum physics", "robotics", 
    "creative writing", "biochemistry", "philosophy", "art history", 
    "mechanical engineering", "data science"
];

// Function to generate random students
function generateRandomStudents(numStudents, departments, subjects) {
    const students = [];

    for (let i = 0; i < numStudents; i++) {
        const student = {
            name: faker.person.fullName(),
            department: faker.helpers.arrayElement(departments),
            electives: []
        };

        // Randomize the number of electives (at least one, max 10)
        const numElectives = faker.datatype.number({ min: 1, max: 10 });
        const selectedSubjects = faker.helpers.arrayElements(subjects, numElectives);

        selectedSubjects.forEach((subject, index) => {
            student.electives.push({
                subject: subject,
                priority: index + 1
            });
        });

        students.push(student);
    }

    return students;
}

// Generate the JSON structure
const data = {
    configuration: {
        restrict_department: true
    },
    electives: subjects.map(subject => ({
        subject: subject,
        max_students: 50,
        min_students: 2,
        mode: faker.helpers.arrayElement(["in-person", "online"])
    })),
    departments: departments.reduce((acc, department) => {
        acc[department] = {
            electives_min: 1,
            electives_max: 10
        };
        return acc;
    }, {}),
    students: generateRandomStudents(numStudents, departments, subjects)
};

// Save the generated JSON to a file
fs.writeFileSync('asymmetric_random_extended.json', JSON.stringify(data, null, 4));

// Function to execute the Gale-Shapley algorithm
function galeShapleyAlgorithm(data) {
    const electives = data.electives.reduce((acc, elective) => {
        acc[elective.subject] = {
            max_students: elective.max_students,
            min_students: elective.min_students,
            enrollments: []
        };
        return acc;
    }, {});

    const students = data.students.reduce((acc, student) => {
        acc[student.name] = {
            department: student.department,
            preferences: student.electives.sort((a, b) => a.priority - b.priority)
        };
        return acc;
    }, {});

    let freeStudents = Object.keys(students); // Initially, all students are free

    // Function to get the next free student who still has preferences
    function getFreeStudent() {
        return freeStudents.find(student => students[student].preferences.length > 0);
    }

    // Main matching process
    while (freeStudents.length > 0) {
        const student = getFreeStudent();
        if (!student) break; // No free students with preferences left

        // Get the highest priority elective for this student
        const electiveChoice = students[student].preferences.shift().subject;

        if (electives[electiveChoice].enrollments.length < electives[electiveChoice].max_students) {
            // If there's room, enroll the student
            electives[electiveChoice].enrollments.push(student);
            freeStudents = freeStudents.filter(s => s !== student); // Student is no longer free
        } else {
            // If the elective is full, no action is taken (could add bumping logic here)
        }
    }

    // Redistribution logic to ensure minimum enrollment
    for (const elective of Object.keys(electives)) {
        while (electives[elective].enrollments.length < electives[elective].min_students) {
            // Find a free student who hasn't been placed in any elective yet
            const student = freeStudents.shift();
            if (!student) break; // No free students left to place

            // Assign the student to this elective
            electives[elective].enrollments.push(student);
        }
    }

    // Print the results of the enrollments
    console.log("Enrollment Results:");
    for (const [elective, details] of Object.entries(electives)) {
        if (details.enrollments.length >= details.min_students) {
            console.log(`${elective}: ${details.enrollments.join(', ')}`);
        } else {
            console.log(`${elective}: Not enough students enrolled (minimum required: ${details.min_students}).`);
        }
    }
}

// Call the function with the generated data
galeShapleyAlgorithm(data);

